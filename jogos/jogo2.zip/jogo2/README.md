<h1 align="center">
    <img src="memory-game-javascript.png" alt="Memory game created in JavaScript" />
</h1>
<h4 align="center">You can read the written tutorial about the implementation on <strong><a href="https://www.webtips.dev/memory-game-in-javascript">webtips.dev</a></strong> 🧠</h4>
